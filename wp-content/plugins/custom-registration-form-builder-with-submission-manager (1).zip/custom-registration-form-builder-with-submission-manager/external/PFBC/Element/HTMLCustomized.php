<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of HTMLCustomized
 *
 * @author hawk
 */
class Element_HTMLCustomized extends Element_HTML {
    
        public function __construct($value,$class=null) {
		parent::__construct($value);
	}
}
