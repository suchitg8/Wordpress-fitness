var iflychat_bundle = document.createElement("SCRIPT");
iflychat_bundle.src = "//cdn.iflychat.com/js/iflychat-v2.min.js?app_id="+iflychat_app_id;
iflychat_bundle.async="async";
document.body.appendChild(iflychat_bundle);