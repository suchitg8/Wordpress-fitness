var iflychat_popup=document.createElement("DIV");
iflychat_popup.className="iflychat-popup";
document.body.appendChild(iflychat_popup);