<?php
  if(isset($rm_promo_banner_title))
      $title = $rm_promo_banner_title;
  else
      $title = 'Upgrade and expand the power of';
?>
<div class="rm-upgrade-note-gold">        
        <div class="rm-banner-title"><?php echo $title; ?><img src="<?php echo RM_IMG_URL.'logo.png'?>"> </div>
        <div class="rm-banner-subtitle">Choose from three powerful extension bundles</div>
        <div class="rm-banner-box"><a href="https://registrationmagic.com/?download_id=317&edd_action=add_to_cart" target='blank'><img src="<?php echo RM_IMG_URL.'silver-logo.png'?>"></a>

        </div>
        <div class="rm-banner-box"><a href="https://registrationmagic.com/?download_id=23029&edd_action=add_to_cart" target="blank"><img src="<?php echo RM_IMG_URL.'gold-logo.png'?>"></a>

        </div>
        <div class="rm-banner-box"><a href="https://registrationmagic.com/?download_id=22865&edd_action=add_to_cart" target="blank"><img src="<?php echo RM_IMG_URL.'platinum-logo.png'?>"></a>

        </div>
</div>

