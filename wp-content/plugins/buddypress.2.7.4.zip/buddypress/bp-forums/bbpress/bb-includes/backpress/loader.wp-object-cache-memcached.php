<?php

require_once( 'class.wp-object-cache-memcached.php' );
require_once( 'functions.wp-object-cache.php' );
