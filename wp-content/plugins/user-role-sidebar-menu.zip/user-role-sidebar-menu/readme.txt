=== User role sidebar menu ===
Contributors: Achyuth401
Donate : b.achyuthkumar[@]gmail.com.
Plugin link: http://phpmake.wordpress.com/2014/02/13/user-role-sidebar-menu-plugin/
Tags: user role sidebar menu,role base menu, sidebar menu, menus
Requires at least: 3.0
Tested up to: 4.5.2
Stable tag: 0.0.2
License: GPLv2 or later

Manage custom Sidebar menus based on logged-in user.

== Description ==

Welcome to User role sidebar menu..! This plugin allows you to Manage custom Sidebar menus based on logged-in user and you can assign different custom menus for different user roles on WordPress pages.

== Installation ==

1. Upload the `plugin` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Appearance > Widgets
4. Drag and drop User role sidebar menu widget to specific page sidebar location
5. Choose user role and custom menu for this widget. 1,2,3 done..!
6. For more info see the plugin Screenshots.

== Screenshots ==

1. This screen shot describes on WP dashboard side. 
Screenshots in the /assets directory take precedence. For example, `/assets/screenshot-1.png`
 
2. This is the second screen shot for front end side
Screenshots in the /assets directory take precedence. For example, `/assets/screenshot-2.png`

== Frequently Asked Questions ==

= How to create custom menu =

Go to Appearance > menus > Create new menu

== Changelog ==

0.0.2 Add CSS file to show ul li item in parallel.

0.0.1. Initial release.





