<?php

/**
  * Good Health Functions
  *
**/

require get_template_directory() . '/library/good_health.php'; 
require get_template_directory() . '/library/functions/functions.php'; 
require get_template_directory() . '/library/customizer/controls.php';
require get_template_directory() . '/library/customizer/display.php';
require get_template_directory() . '/library/functions/custom-functions.php';

?>